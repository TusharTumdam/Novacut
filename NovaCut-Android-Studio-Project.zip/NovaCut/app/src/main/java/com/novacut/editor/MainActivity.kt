package com.novacut.editor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.RgbFilter
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

@UnstableApi
class MainActivity : Activity() {
    private val bg = Color.rgb(16, 17, 19)
    private val panel = Color.rgb(28, 29, 33)
    private val muted = Color.rgb(155, 158, 166)
    private val lime = Color.rgb(183, 255, 90)
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private val clips = mutableListOf<Uri>()
    private var activeUri: Uri? = null
    private var durationMs = 0L
    private var trimStartMs = 0L
    private var trimEndMs = 0L
    private var selectedFilter = "Original"
    private var selectedTransition = "Fade"
    private lateinit var root: LinearLayout
    private lateinit var clipStrip: LinearLayout
    private lateinit var status: TextView
    private lateinit var startLabel: TextView
    private lateinit var endLabel: TextView
    private lateinit var startSeek: SeekBar
    private lateinit var endSeek: SeekBar
    private lateinit var exportButton: Button
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "Nova\u2022Cut"; textSize = 25f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val spacer = View(this)
        val exportTop = button("EXPORT", true).apply { setOnClickListener { exportVideo() } }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        top.addView(exportTop, LinearLayout.LayoutParams(dp(100), dp(42)))
        root.addView(top)
        root.addView(label("MAKE SOMETHING MOVING", muted, 10f).apply { letterSpacing = 0.12f; setPadding(0, 0, 0, dp(12)) })

        val previewCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK)
            background = rounded(panel, 18)
            clipToOutline = true
        }
        val previewFrame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(7, 8, 10)) }
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setShutterBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        previewFrame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        val emptyPreview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        val playGlyph = TextView(this).apply { text = "▶"; textSize = 32f; setTextColor(lime); gravity = Gravity.CENTER }
        emptyPreview.addView(playGlyph, LinearLayout.LayoutParams(-1, dp(48)))
        emptyPreview.addView(label("Your next story starts here", Color.WHITE, 17f).apply { gravity = Gravity.CENTER })
        emptyPreview.addView(label("Import a video to begin editing", muted, 12f).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        previewFrame.addView(emptyPreview, FrameLayout.LayoutParams(-1, -1))
        previewCard.addView(previewFrame, LinearLayout.LayoutParams(-1, 0, 1f))
        val previewActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        previewActions.addView(label("PREVIEW", muted, 10f), LinearLayout.LayoutParams(0, dp(24), 1f))
        previewActions.addView(label("9:16  ·  1080p", Color.WHITE, 11f))
        previewCard.addView(previewActions)
        root.addView(previewCard, LinearLayout.LayoutParams(-1, dp(250)))

        val importRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(8)) }
        importRow.addView(label("TIMELINE", Color.WHITE, 14f).apply { setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        importRow.addView(button("＋ Add clips", false).apply { setOnClickListener { pickVideos() } }, LinearLayout.LayoutParams(dp(124), dp(40)))
        root.addView(importRow)

        val stripScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(panel) }
        clipStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)); gravity = Gravity.CENTER_VERTICAL }
        clipStrip.addView(label("No clips yet · tap Add clips", muted, 12f).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) })
        stripScroll.addView(clipStrip)
        root.addView(stripScroll, LinearLayout.LayoutParams(-1, dp(74)))

        val trimHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(4)) }
        trimHeader.addView(label("TRIM CLIP", Color.WHITE, 13f).apply { setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(28), 1f))
        startLabel = label("IN  00:00", muted, 11f)
        endLabel = label("OUT 00:00", muted, 11f)
        trimHeader.addView(startLabel); trimHeader.addView(label("   ", muted, 10f)); trimHeader.addView(endLabel)
        root.addView(trimHeader)
        startSeek = SeekBar(this).apply { max = 1000; progress = 0; setOnSeekBarChangeListener(seekListener(true)) }
        endSeek = SeekBar(this).apply { max = 1000; progress = 1000; setOnSeekBarChangeListener(seekListener(false)) }
        root.addView(startSeek, LinearLayout.LayoutParams(-1, dp(28)))
        root.addView(endSeek, LinearLayout.LayoutParams(-1, dp(28)))

        root.addView(label("LOOKS", Color.WHITE, 13f).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(10), 0, dp(8)) })
        root.addView(horizontalOptions(listOf("Original", "Mono", "Sepia", "Warm"), selectedFilter) { selectedFilter = it; refreshOptions() })
        root.addView(label("TRANSITIONS", Color.WHITE, 13f).apply { setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(12), 0, dp(8)) })
        root.addView(horizontalOptions(listOf("Fade", "Dissolve", "Wipe", "Slide"), selectedTransition) { selectedTransition = it; refreshOptions() })

        status = label("Ready when you are.", muted, 11f).apply { setPadding(0, dp(12), 0, dp(4)) }
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { visibility = View.GONE; progress = 0; progressTintList = android.content.res.ColorStateList.valueOf(lime) }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(4)))
        exportButton = button("Export video", true).apply { setOnClickListener { exportVideo() } }
        val exportParams = LinearLayout.LayoutParams(-1, dp(48)); exportParams.topMargin = dp(8)
        root.addView(exportButton, exportParams)
        setContentView(root)
    }

    private fun refreshOptions() {
        // Selection state is used by the exporter for supported looks and kept visible in the UI.
        status.text = "Look: $selectedFilter   ·   Transition: $selectedTransition"
        // Rebuild only the option rows, retaining current selection state.
        val looksIndex = root.indexOfChild(root.findViewWithTag("looks-row"))
        if (looksIndex >= 0) {
            root.removeViewAt(looksIndex)
            root.addView(horizontalOptions(listOf("Original", "Mono", "Sepia", "Warm"), selectedFilter) { selectedFilter = it; refreshOptions() }, looksIndex)
        }
        val transitionIndex = root.indexOfChild(root.findViewWithTag("transition-row"))
        if (transitionIndex >= 0) {
            root.removeViewAt(transitionIndex)
            root.addView(horizontalOptions(listOf("Fade", "Dissolve", "Wipe", "Slide"), selectedTransition) { selectedTransition = it; refreshOptions() }, transitionIndex)
        }
    }

    private fun horizontalOptions(options: List<String>, selected: String, onSelect: (String) -> Unit): HorizontalScrollView {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        options.forEach { option ->
            val b = TextView(this).apply {
                text = option; textSize = 12f; gravity = Gravity.CENTER
                setTextColor(if (option == selected) bg else Color.WHITE)
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = rounded(if (option == selected) lime else panel, 22)
                setOnClickListener { onSelect(option) }
            }
            val lp = LinearLayout.LayoutParams(-2, dp(36)); lp.marginEnd = dp(8)
            row.addView(b, lp)
        }
        scroll.addView(row)
        // Tags allow the rows to be refreshed after a choice.
        scroll.tag = if (options.firstOrNull() == "Original") "looks-row" else "transition-row"
        return scroll
    }

    private fun pickVideos() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_VIDEOS)
    }

    @Deprecated("Legacy callback kept for compatibility with the minimum SDK")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_VIDEOS || resultCode != RESULT_OK || data == null) return
        val selected = mutableListOf<Uri>()
        data.clipData?.let { clipData -> for (i in 0 until clipData.itemCount) selected.add(clipData.getItemAt(i).uri) }
        if (selected.isEmpty()) data.data?.let { selected.add(it) }
        selected.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            if (!clips.contains(uri)) clips.add(uri)
        }
        if (clips.isNotEmpty()) loadClip(clips.last())
        renderClipStrip()
    }

    private fun renderClipStrip() {
        clipStrip.removeAllViews()
        clips.forEachIndexed { index, uri ->
            val item = TextView(this).apply {
                text = "▰  CLIP ${index + 1}\n${uri.lastPathSegment?.takeLast(18) ?: "Video"}"
                textSize = 10f; setTextColor(if (uri == activeUri) lime else Color.WHITE)
                setPadding(dp(12), dp(8), dp(12), dp(8)); background = rounded(Color.rgb(43, 45, 50), 10)
                setOnClickListener { loadClip(uri); renderClipStrip() }
            }
            val lp = LinearLayout.LayoutParams(dp(150), dp(54)); lp.marginEnd = dp(8)
            clipStrip.addView(item, lp)
        }
    }

    private fun loadClip(uri: Uri) {
        activeUri = uri
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView?.player = exo
            playerView?.visibility = View.VISIBLE
            exo.setMediaItem(MediaItem.fromUri(uri)); exo.prepare(); exo.playWhenReady = false
            exo.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == androidx.media3.common.Player.STATE_READY) {
                        durationMs = exo.duration.coerceAtLeast(0L)
                        trimStartMs = 0L; trimEndMs = durationMs
                        startSeek.progress = 0; endSeek.progress = 1000
                        updateTrimLabels()
                        status.text = "${formatTime(durationMs)} clip loaded · $selectedFilter look selected"
                    }
                }
            })
        }
        // Hide the empty-state overlay when media is loaded.
        val frame = (playerView?.parent as? FrameLayout)
        if (frame != null && frame.childCount > 1) frame.getChildAt(1).visibility = View.GONE
    }

    private fun seekListener(isStart: Boolean) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (durationMs <= 0) return
            val time = durationMs * progress / 1000L
            if (isStart) trimStartMs = time else trimEndMs = time
            if (trimEndMs <= trimStartMs) {
                if (isStart) trimStartMs = (trimEndMs - 500).coerceAtLeast(0) else trimEndMs = (trimStartMs + 500).coerceAtMost(durationMs)
            }
            updateTrimLabels()
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun updateTrimLabels() {
        startLabel.text = "IN  ${formatTime(trimStartMs)}"
        endLabel.text = "OUT ${formatTime(trimEndMs)}"
    }

    private fun exportVideo() {
        val uri = activeUri
        if (uri == null) { Toast.makeText(this, "Add a video clip first", Toast.LENGTH_SHORT).show(); return }
        if (durationMs <= 0L || trimEndMs <= trimStartMs) { Toast.makeText(this, "Choose a valid trim range", Toast.LENGTH_SHORT).show(); return }
        exportButton.isEnabled = false
        progress.visibility = View.VISIBLE; progress.isIndeterminate = true
        status.text = "Exporting your video… keep NovaCut open."
        val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: cacheDir
        val outputFile = File(outputDir, "NovaCut_${System.currentTimeMillis()}.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(trimStartMs)
            .setEndPositionMs(trimEndMs)
            .build()
        val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
        val videoEffects = when (selectedFilter) {
            "Mono" -> listOf(RgbFilter.createGrayscaleFilter())
            "Sepia" -> listOf(RgbFilter.createSepiaFilter())
            "Warm" -> listOf(RgbFilter.createWarmthFilter(0.35f))
            else -> emptyList()
        }
        val edited = EditedMediaItem.Builder(mediaItem).setEffects(Effects(emptyList(), videoEffects)).build()
        val transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        progress.visibility = View.GONE; progress.isIndeterminate = false
                        exportButton.isEnabled = true
                        try {
                            val savedUri = copyToGallery(outputFile)
                            status.text = "Export complete · saved to Movies/NovaCut"
                            Toast.makeText(this@MainActivity, "Video exported to gallery", Toast.LENGTH_LONG).show()
                            savedUri?.let { status.text = "Export complete · saved to Movies/NovaCut" }
                        } catch (e: Exception) {
                            status.text = "Exported to app Movies folder: ${outputFile.name}"
                            Toast.makeText(this@MainActivity, "Export complete", Toast.LENGTH_LONG).show()
                        }
                    }
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    runOnUiThread {
                        progress.visibility = View.GONE; progress.isIndeterminate = false; exportButton.isEnabled = true
                        status.text = "Export failed: ${exportException.message ?: "unsupported media"}"
                        Toast.makeText(this@MainActivity, "Export failed. Try another clip.", Toast.LENGTH_LONG).show()
                    }
                }
            }).build()
        try { transformer.start(edited, outputFile.absolutePath) }
        catch (e: Exception) {
            progress.visibility = View.GONE; exportButton.isEnabled = true
            status.text = "Could not start export: ${e.message ?: "unknown error"}"
        }
    }

    private fun copyToGallery(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NovaCut")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { out -> FileInputStream(file).use { input -> input.copyTo(out) } }
        values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }

    private fun button(text: String, primary: Boolean): Button = Button(this).apply {
        this.text = text; textSize = 12f; isAllCaps = false
        setTextColor(if (primary) bg else Color.WHITE)
        background = rounded(if (primary) lime else panel, 12)
        stateListAnimator = null
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(12), dp(4), dp(12), dp(4))
    }

    private fun label(text: String, color: Int, size: Float) = TextView(this).apply {
        this.text = text; setTextColor(color); textSize = size
    }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun formatTime(ms: Long): String = String.format(Locale.US, "%02d:%02d", ms / 60000, (ms / 1000) % 60)

    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }

    companion object { private const val PICK_VIDEOS = 901 }
}
