# NovaCut — Android video editor starter

NovaCut is an original Android Studio project inspired by the general workflow of mobile video editors. It does not reuse FilmoraGo code, assets, branding, or implementation.

## Implemented in this starter

- Dark NovaCut editing UI
- Import one or more videos using Android's system document picker
- Preview the selected clip with ExoPlayer
- Clip list/timeline strip with clip selection
- In/out trim controls
- Export the selected clip to MP4 using AndroidX Media3 Transformer
- Export looks: Original, monochrome, sepia, and warm
- Save successful exports to `Movies/NovaCut`
- Transition-style selection controls in the editor UI

## Important scope notes

This is a first functional starter, **not yet a complete FilmoraGo-equivalent editor**. The current export pipeline exports the selected clip only. The transition selector is currently UI state and does not yet render transitions between multiple clips. Music overlays, text/sticker layers, keyframes, project persistence, undo/redo, and a multi-clip composition export are not implemented yet. The UI should not be represented as having those functions until they are added and tested.

## Build an installable APK

This environment did not have the Android SDK/Gradle installed and could not reach Google's download servers, so no compiled or tested APK is included. To build it on a computer with Android Studio:

1. Install Android Studio and the Android SDK Platform 35.
2. Open this `NovaCut` folder in Android Studio.
3. Allow Gradle to sync and download AndroidX Media3 dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will produce the debug APK under `app/build/outputs/apk/debug/`.

Command-line alternative from this directory, after installing Android SDK and Gradle:

```bash
gradle assembleDebug
```

## Technical details

- Language: Kotlin
- UI: Android Views, built programmatically
- Playback: AndroidX Media3 ExoPlayer
- Export: AndroidX Media3 Transformer
- Package/application ID: `com.novacut.editor`
- Minimum Android version: Android 7.0 (API 24)
- Target/compile SDK: 35

## Next steps for a full editor

1. Replace the current clip strip with a multi-track timeline and persistent project model.
2. Export multiple clips as a Media3 `Composition`, applying transitions between adjacent sequences.
3. Add music/audio tracks with volume, fade-in/out, and waveform display.
4. Add text, stickers, and timed overlays.
5. Add aspect ratio, crop, speed, and color adjustments.
6. Add export resolution/frame-rate controls and test on a range of Android devices.
